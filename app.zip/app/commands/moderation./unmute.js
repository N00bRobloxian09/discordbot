const Discord = require("discord.js");
const ms = require("ms");
const { readdirSync } = require("fs");

module.exports.run = async (bot, message, args) => {

    if (!message.member.hasPermissions ('MANAGE_MESSAGES')) return message.channel.send("Error: You dont have permissions to use this command!")
    const modlog = message.guild.channels.find(channel => channel.name === 'logs');
    const mod = message.author;
    let user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if (!user) return message.reply("Syntax error: user not specified!")
    let reason = message.content.split(" ").slice(2).join(" ");
    if (!user.roles.find(`name`, "Muted")) return message.channel.send('There are\'t in muted.')
    if (!reason) return message.reply('Syntax error: reason not specified!')
    let muterole = message.guild.roles.find(`name`, "Muted");
    if(args[0] == "helcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccp"){
      message.reply("Usage: k!unmute <user> <reason>");
      return;
    }
  let muteChannel = message.guild.channels.find(`name`, "logs");
  if (!muteChannel) return message.channel.send('**Please create a channel with the name `logs`**')

    if (!muterole) {
        try {
            muterole = await message.guild.createRole({
                name: "Muted",
                color: "#000000",
                permissions: []
            })
            message.guild.channels.forEach(async (channel, id) => {
                await channel.overwritePermissions(muterole, {
                    SEND_MESSAGES: false,
                    ADD_REACTIONS: false
                });
            });
        } catch (e) {
            console.log(e.stack);
        }
    }
  

    let mutetime = args[1];

    await (user.removeRole(muterole.id));
    const muteembed = new Discord.RichEmbed()
            .setAuthor(' Unmute - User ')
            .addField('User', `<@${user.id}>`)
            .addField('Reason', `${reason}`)
            .addField('Moderator', `${mod}`)
            .setColor('#000000')
            .setFooter('Information', user.displayAvatarURL);
        modlog.send(muteembed)
  
  
}


module.exports.help = {
  name: "unmute",
  description: "",
  usage: "",
  category: "moderation",
  aliases: [""]
};