const discord = require("discord.js");
const config = require('../../config.json');
const { readdirSync } = require("fs");

module.exports.run = async (bot, message, args) => {

let target = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
let reason = args.slice(1).join(' ');
let logs = message.guild.channels.find('name', config.logsChannel);
if (!message.member.hasPermission('BAN_MEMBERS')) return message.reply('Error: You dont have permissions to use this command!');
if (!target) return message.reply('Syntax error: user not specified!');
if (!reason) return message.reply('Syntax error: reason not specified');
if (!logs) return message.reply(`Please create a channel called ${config.logsChannel} to log the bans!`);

let embed = new discord.RichEmbed()
.setAuthor(' Ban - User ')
.setColor('#ff0000')
.setThumbnail(target.user.avatarURL)
.addField('Member Banned', `${target.user.username}`)
.addField('Banned By', `${message.author.username}`)
.addField('Banned Reason', reason)
.setFooter(`${message.guild.name} Ban`, target.user.displayAvatarURL);

message.channel.send(`${target.user.username} was banned by ${message.author} for ${reason}`);

target.ban(reason);
logs.send(embed);

};
module.exports.help = {
  name: "pban",
  description: "",
  usage: "",
  category: "moderation",
  aliases: [""]
};