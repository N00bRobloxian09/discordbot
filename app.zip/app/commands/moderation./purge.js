const discord = require ("discord.js");
const { readdirSync } = require("fs");
exports.run = (bot, message, args)  => { 
  if (!message.member.hasPermission ('MANAGE_MESSAGES')) return message.reply('Error: You dont have permissions to use this command!');
  if (isNaN(args[0])) return message.channel.send('Please enter valid amount!')
  if (args [0] >  300) return message.channel.send('Please enter number that is lower than 300!')
  message.channel.bulkDelete(args[0])
  .then( messages => message.channel.send(`**Messages deleted: \`${messages.size}/${args[0]}\` messages**`).then( msg => msg.delete({ timeout: 10000})))
  .catch( error => message.channel.send(`**ERROR:** ${error.message}`));
};
module.exports.help = {
  name: "purge",
  description: "",
  usage: "",
  category: "moderation",
  aliases: [""]
};