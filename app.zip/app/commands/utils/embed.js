const Discord = require("discord.js");
const config = require("../../config.json");
const { readdirSync } = require("fs");

module.exports.run = async (bot, message, args) => {
  let logs = message.guild.channels.find("name", config.logsChannel);
  if (!logs)
    return message.reply(
      `please create a channel called ${config.logsChannel} to log the N/A!`
    );
  if (!message.member.hasPermission("MENTION_EVERYONE"))
    return message.reply(
      "Error: You dont have permission to use this command!"
    );
  const sayMessage = args.join(" ");
  message.delete().catch();
  let embedsay = new Discord.RichEmbed()
    .setColor("RANDOM")
    .setDescription(sayMessage);
  message.channel.send(embedsay);
  let embed = new Discord.RichEmbed()
    .setTitle(`embed command executed by ${message.author.username}`)
    .setDescription(`In channel, ${message.channel}`)
    .addField(`Subject:`, sayMessage);
  logs.send(embed);
};

module.exports.help = {
  name: "embed",
  description: "embed",
  usage: "embed (message)",
  category: "Utils",
  aliases: ["embedc"]
};
