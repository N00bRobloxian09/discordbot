const Discord = require('discord.js');
const { readdirSync } = require("fs");

exports.run = async (client, message, args, tools) => {
  
  if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.channels.send('Error: You dont have permission to use this command!');
  if (!args.join(' ')) return message.channel.send('Error: Poll Cant be blank!');
  
  const embed = new Discord.RichEmbed()
    .setTitle(`Poll by, ${message.author.tag}`)
    .setDescription(args.join(' '))
    .setFooter(`${message.guild.name} Poll`)
    .setColor('#2C2F33')
    const pollTitle = await message.channel.send({ embed });
      await pollTitle.react(`❎`);
      await pollTitle.react(`✅`);

};
module.exports.help = {
  name: "pollcreate",
  description: "creates a poll",
  usage: "poll (question)",
  category: "Utils",
  aliases: ["pollc"]
};