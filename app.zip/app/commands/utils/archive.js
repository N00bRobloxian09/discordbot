const Discord = require("discord.js");
const moment = require("moment");
const fs = require('fs');

module.exports.run = async (client, message, args) => {
  message.channel.fetchMessages().then(async messages => {
    console.log(`${messages.size} procuradas.`);

    let finalArray = [];

    const putInArray = async data => finalArray.push(data);
    const handleTime = timestamp =>
      moment(timestamp)
        .format("[ DD/MM/YYYY hh:mm:ss a ]")
        .replace("pm", "PM")
        .replace("am", "AM");

    for (const message of messages.array().reverse())
      await putInArray(
        `${handleTime(message.timestamp)} ${message.author.username}: ${
          message.content
        }`+'\n'
      );

    //console.log(finalArray);
    console.log(finalArray.length);
     fs.writeFile('./log.txt', finalArray, (err) => {
     if(err) throw err;
    });
    message.channel.send("Chat archived:", { files: ["./log.txt"] });
  });
};

module.exports.help = {
  name: "archive",
  description: "archives a channel (all messages)",
  usage: "archive",
  category: "Utils",
  aliases: [""]
};
