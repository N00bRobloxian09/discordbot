const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
     
    if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply('Error: You dont have permission to use this command!');
    let specifyembed = new Discord.RichEmbed()
        .setDescription(`${message.author} You cant announce nothing!`)

    if (!args[0]) return message.channel.send(specifyembed);
    
    let embedsay = new Discord.RichEmbed()
        .setColor('#2c2f33')
        .setAuthor(`Announcement by ${message.author.tag}!`)
        .setFooter(`${message.guild.name} Announcement`)
        .setDescription (args.join(" "));

  message.delete(500)
  message.channel.send(embedsay);
  
};

module.exports.help = {
  name: "announce",
  description: "announcement creator",
  usage: "announce <mesage>",
  category: "Utils",
  aliases: [""]
}; 