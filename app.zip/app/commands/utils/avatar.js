const Discord = require("discord.js");
module.exports.run = async (bot, message, args) => {
  
var user = message.mentions.first();
    const avatarEmbed = new Discord.RichEmbed()
        .setColor(0x333333)
        .setAuthor(user.username)
        .setImage(user.avatarURL);
  
    message.channel.send(avatarEmbed);
}

module.exports.run = {
  name: "avatar",
  description: "por",
  usage: "oof",
  category: "Utils",
  aliases: ["avr"]
};