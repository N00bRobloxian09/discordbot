const {RichEmbed} = require("discord.js");
const { readdirSync } = require("fs");

exports.run = async (client, message, args, level) => {
  
if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply('You dont have permission to use this command!'); {
  
var nameResult = args.join(' ');
if (!nameResult) nameResult = null;
  
client.user.setActivity(nameResult, {type: "PLAYING"});
  
let embed = new RichEmbed()
.setAuthor(`User: ${message.author.tag}`, `${message.author.avatarURL}`)
.setDescription(`${nameResult} set as status!`)
message.channel.send(embed)
}
}
module.exports.help = {
  name: "status",
  description: "sets 30 minute bot status",
  usage: "status (message)",
  category: "Utils",
  aliases: ["statuschange"]
};