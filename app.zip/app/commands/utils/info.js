const Discord = require("discord.js");
const { readdirSync } = require("fs");
module.exports.run = async (bot, message, args) => {
    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
    .setTitle(message.guild.name,"Information")
    .setColor("#2c2f33") //("#a9a9a9")
    .setThumbnail(sicon)
  //  .addField("Owner:", "Drup#3325")
    .addField("Creation Date:", message.guild.createdAt)
    .addField("Member Count:", message.guild.memberCount);

    message.channel.send(serverembed);
}
module.exports.help = {
  name: "serverinfo",
  description: "shows serverinfo",
  usage: "serverinfo",
  category: "Utils",
  aliases: [""]
};