(function newFact() {
  var facts = ['584354', '867854', '335421'];
  var randomFact = Math.floor(Math.random() * facts.length);
  document.getElementById('wart').innerHTML = facts[randomFact];
  })();